<?php

print_r(1);